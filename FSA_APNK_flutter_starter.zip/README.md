# FSA APNK — prototype Flutter

Application de démonstration pour la gestion du Fonds Social des Agents APNK.

## Installation dans le dépôt existant
1. Conserver le dossier `android/` créé par Flutter.
2. Remplacer le contenu de `lib/main.dart` par le fichier fourni dans `lib/main.dart`.
3. Comparer le `pubspec.yaml` fourni avec celui du projet et conserver les paramètres propres au projet si nécessaire.
4. Dans le terminal Codespaces :
   ```bash
   flutter pub get
   flutter analyze
   flutter run -d chrome
   ```
5. Pour compiler l'APK Android (avec Android SDK et licences configurés) :
   ```bash
   flutter build apk --release
   ```
   L'APK sera dans `build/app/outputs/flutter-apk/app-release.apk`.

## Important
Ce prototype utilise des données en mémoire pour illustrer l'interface et les parcours. Les ajouts ne sont pas encore persistés après fermeture. Avant un usage réel, ajouter une base de données persistante, authentification, rôles, sauvegardes et journal d'audit.
